<script>
  import { goto } from "$app/navigation";
  import { onMount } from "svelte";

  let isMenuOpen = false;
  let isScriptRunning = false;

  async function runScript(scriptName) {
    isScriptRunning = true;
    const response = await fetch(`/api/run-script?scriptName=${scriptName}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });
    const data = await response.json();
    isScriptRunning = false;
  }

  function toggleMenu() {
    isMenuOpen = !isMenuOpen;
    const dropdownMenu = document.getElementById("dropdownMenu");
    if (isMenuOpen) {
      dropdownMenu.style.display = "block";
    } else {
      dropdownMenu.style.display = "none";
    }
  }

  onMount(() => {
    const dropdownMenu = document.getElementById("dropdownMenu");
    dropdownMenu.style.display = "none";
  });
</script>

<div class="container max-w-full h-[50vh] flex flex-col">
  <header class="bg-purple-700 p-4 flex items-center text-white">
    <button
      class="menu-icon text-2xl mr-4"
      on:click={toggleMenu}
      aria-label="Toggle menu"
    >
      ☰
    </button>
    <div class="logo text-xl font-bold tracking-widest">SentinelScan</div>
  </header>

  <div
    id="dropdownMenu"
    class="dropdown-menu hidden absolute top-[60px] left-[20px] bg-purple-700 p-4 rounded-lg flex-col gap-2 z-10 transition-all duration-300"
  >
    <button
      class="bg-none border-2 border-purple-300 text-white font-bold text-lg py-2 px-4 rounded-lg hover:bg-purple-300"
    >
      Scanner
    </button>
    <button
      class="bg-none border-2 border-purple-300 text-white font-bold text-lg py-2 px-4 rounded-lg hover:bg-purple-300"
    >
      Terms and Conditions
    </button>
    <button
      on:click={goto("/about-us")}
      class="bg-none hover:bg-purple-300 hover:text-black border-2 border-purple-300 text-white font-bold text-lg py-2 px-4 rounded-lg"
    >
      About Us
    </button>
  </div>

  <main
    class="bg-gradient-to-br from-purple-500 to-gray-900 rounded-lg p-8 m-8 text-center flex flex-col justify-center flex-grow"
  >
    <h2 class="text-lg tracking-widest mb-4">WELCOME TO</h2>
    <h1
      class="text-4xl font-bold text-shadow-lg mb-8"
      style="text-shadow: 2px 2px 0 #000, 2px 2px 5px #e57aff"
    >
      SentinelScan
    </h1>
    <p
      class="tagline bg-purple-700 border-2 border-purple-300 rounded-lg py-3 px-6 inline-block font-bold text-lg"
    >
      Your Beloved Vulnerability Scanner
    </p>
  </main>

  <button
    class="menu-icon text-2xl bg-none border-2 border-purple-300 font-bold py-2 px-4 rounded-lg hover:bg-purple-300"
    on:click={() => runScript("script1")}
    aria-label="Toggle menu"
  >
    Run script
  </button>
</div>
