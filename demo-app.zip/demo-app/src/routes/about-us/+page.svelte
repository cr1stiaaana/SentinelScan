<script>
  // You can add any JavaScript logic here if needed
</script>

<div class="about-us">
  <h1>About Us</h1>
  <p>
    Welcome to our website! We are a passionate team dedicated to delivering the
    best experience for our users. Our mission is to create innovative solutions
    that make a difference in people's lives. Thank you for visiting and being a
    part of our journey!
  </p>
</div>

<style>
  @import "../+page.css";
</style>
